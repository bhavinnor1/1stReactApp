import React from "react";

const About = () => {
    return (

        <div className="about">ABout</div>
    )
}
export default About;