import React from "react";
function Footer(){
    return (
        <div className="footer">
            &copy; Copyright. All Rights Reserved. NorTechnical 2021.
        </div>
    )
}
export default Footer;