import React from "react";

function Home(props){
    return(
        <div className="center">
            <div className="grid">
                <div className="grid-item">
                    <h1>Grow Your Business With</h1>
                    <h1 style={{color:'rgb(147, 214, 45)'}}>REACT</h1>
                    <h3>We are here to get the best website!!!</h3>
                    <a>GET STARTED</a>
                </div>
                <div className="grid-item">
                    <img src={props.img} alt="An Image of a person Programming..." className="img"/>
                </div>
            </div>
        </div>
    )
}
export default Home;